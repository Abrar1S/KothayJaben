package com.example.abrar.test1;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.os.Build;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;

import android.support.v4.app.FragmentActivity;

import android.view.View;
import android.widget.Toast;
import android.widget.ZoomControls;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import static com.google.android.gms.common.api.GoogleApiClient.*;

public class navdrawer extends AppCompatActivity implements OnMapReadyCallback, NavigationView.OnNavigationItemSelectedListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,com.google.android.gms.location.LocationListener {

    private DrawerLayout mDrawer;
    private final static int MY_PERMISSION_FINE_LOCATION = 101;
    private GoogleMap mMap;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocaion;
    LocationRequest mLocationRequest;
    private FirebaseAuth auth;
    ZoomControls zoom;
    private ActionBarDrawerToggle mToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navdrawer);
        mDrawer = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawer, R.string.Open, R.string.CLose);
        mDrawer.addDrawerListener(mToggle);
        mToggle.syncState();
        auth = FirebaseAuth.getInstance();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = (NavigationView) findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(navdrawer.this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        zoom = (ZoomControls) findViewById(R.id.zcZoom);
        zoom.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });
        zoom.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }


    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
       // LatLng llp = new LatLng(0, 0);
       // mMap.addMarker(new MarkerOptions().position(llp).title("Position"));
       // mMap.moveCamera(CameraUpdateFactory.newLatLng(llp));
       /* if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            return;

        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSION_FINE_LOCATION);
            }
        }*/
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        buildGoogleApiClient();
        mMap.setMyLocationEnabled(true);
    }
    protected  synchronized void buildGoogleApiClient(){
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener( this )
                .addApi(LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }

   /* LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public
        void onLocationResult(LocationResult locationResult) {
            for (Location location : locationResult.getLocations()) {

            }

        }

    };
    /*@Override
      public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSION_FINE_LOCATION:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)

                        mMap.setMyLocationEnabled(true);
                } else {
                    Toast.makeText(getApplicationContext(),"This App requires Location permission to be granted",Toast.LENGTH_LONG).show();
                    finish();
                }break;

        }

    }*/


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.db){
            startActivity(new Intent(navdrawer.this, just.class));
            finish();
            Toast.makeText(navdrawer.this, "Dashboard", Toast.LENGTH_SHORT).show();
        }
        if(id == R.id.event){
            startActivity(new Intent(navdrawer.this, just.class));
            finish();
            Toast.makeText(navdrawer.this, "Event", Toast.LENGTH_SHORT).show();
        }
        if(id == R.id.settings){
            startActivity(new Intent(navdrawer.this, just.class));
            finish();
            Toast.makeText(navdrawer.this, "Settings", Toast.LENGTH_SHORT).show();
        }
        if(id == R.id.search){
            startActivity(new Intent(navdrawer.this, just.class));
            finish();
            Toast.makeText(navdrawer.this, "search", Toast.LENGTH_SHORT).show();
        }
        if(id == R.id.logout){
            startActivity(new Intent(navdrawer.this, just.class));
            finish();
            Toast.makeText(navdrawer.this, "Logout", Toast.LENGTH_SHORT).show();
        }
        return false;
    }


   /* @Override
    public void onLocationChanged(Location location) {
        mLastLocaion  = location;
        LatLng latlng = new LatLng(location.getLatitude(),location.getLongitude());
        mMap.addMarker(new MarkerOptions().position(latlng).title("Position"));
        mMap.moveCamera( CameraUpdateFactory.newLatLng(latlng));
        mMap.addMarker(new MarkerOptions().position(latlng).title("Position"));
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 11 ) );

    }

   /* @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }*/

    @Override
   public void onLocationChanged(Location location) {

       mLastLocaion = location;
       LatLng latlng = new LatLng( location.getLatitude(), location.getLongitude() );
      // mMap.addMarker( new MarkerOptions().position( latlng ).title( "Position" ) );
       mMap.moveCamera( CameraUpdateFactory.newLatLng( latlng ) );
      /* mMap.addMarker( new MarkerOptions()
                       //.icon( BitmapDescriptorFactory.fromResource( R.drawable.busss) )
                       .position(latlng)
                       .title( "You" ));*/
       mMap.addMarker( new MarkerOptions().position( latlng ).title( "Position" ).icon( BitmapDescriptorFactory.fromResource( R.drawable.busss)));
       mMap.animateCamera( CameraUpdateFactory.zoomTo( 11 ) );

        String userId = auth.getCurrentUser().getUid();
        DatabaseReference reference= FirebaseDatabase.getInstance().getReference("DriversAvailable");
        GeoFire geoFire = new GeoFire(reference);
        geoFire.setLocation(userId,new GeoLocation(location.getLatitude(),location.getLongitude()));

   }

    @SuppressLint("RestrictedApi")
    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval(1000);
        mLocationRequest.setFastestInterval(1000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationRequest,this);

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }



   @Override
    protected void onStop() {
       super.onStop();
       LocationServices.FusedLocationApi.removeLocationUpdates( mGoogleApiClient, this );
       String userId = auth.getCurrentUser().getUid();
       DatabaseReference reference = FirebaseDatabase.getInstance().getReference( "DriversAvailable" );

       GeoFire geoFire = new GeoFire( reference );
       geoFire.removeLocation( userId );
   }
}
