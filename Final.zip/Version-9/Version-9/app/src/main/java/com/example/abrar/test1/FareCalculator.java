package com.example.abrar.test1;

import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.aviran.cookiebar2.CookieBar;
import org.aviran.cookiebar2.OnActionClickListener;

import java.text.DecimalFormat;

public
class FareCalculator extends AppCompatActivity {

    double basefare = 1.8;
    private DecimalFormat df2;

    TextInputEditText cacl1;
    TextInputLayout calculate;
    Button calc2;
    TextView tv1;
    double fare;
    String s1;
    double d2;
    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_fare_calculator );

        calculate = (TextInputLayout)findViewById( R.id.Inputcal );
        cacl1 = (TextInputEditText)findViewById( R.id.calculate );
        calc2 = (Button) findViewById( R.id.farecalculate);
        tv1 = (TextView)findViewById( R.id.result1 );


        calc2.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                s1 = cacl1.getText().toString();
                d2 = Double.parseDouble( s1 );
                fare = basefare*d2;
                df2 = new DecimalFormat( ".##" );
               // tv1.setText("fare: "+fare);
                CookieBar.build(FareCalculator.this)
                        .setTitle("Calculator")
                        .setTitleColor(R.color.input_login)
                        .setDuration(4000)
                        .setLayoutGravity( Gravity.BOTTOM)
                        .setIcon(R.drawable.ic_directions_bus_black_24dp)
                        .setBackgroundColor(R.color.bg_main)
                        .setMessage("Fare: "+df2.format(fare))
                        .setMessageColor(R.color.input_login)
                        .setActionColor(R.color.input_login)
                        .setAction("Ok", new OnActionClickListener() {
                            @Override
                            public void onClick() {

                            }
                        })
                        .show();
            }
        } );


    }
}
