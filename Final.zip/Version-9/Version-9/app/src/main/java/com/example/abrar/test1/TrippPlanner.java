package com.example.abrar.test1;


import android.Manifest;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;

import org.aviran.cookiebar2.CookieBar;
import org.aviran.cookiebar2.OnActionClickListener;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.round;

public
class TrippPlanner extends AppCompatActivity implements OnMapReadyCallback,NavigationView.OnNavigationItemSelectedListener,GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener,com.google.android.gms.location.LocationListener {

    AutoCompleteTextView autoCompleteTextView,autoCompleteTextView2;
    Button ButnTrip,ShowMap;
    TextView Result;
    ImageView im1,im2;
    ArrayList<String>Source ;
    ArrayList<String>Destination,Destination1,Destination2,Destination3,Destination4,Destination5;
    List<Address> address;
    List<Address> address1;
    Geocoder coder,coder1;
    Address location, location1;
    double lat,lng, lat1, lng1;
    private DecimalFormat df2;
    private GoogleMap mMap;
    GoogleApiClient mGoogleApiClient;
    String selection,selection1 = null;
    int c = 0;
    double basefare = 1.8;
    double fare;


    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_tripp_planner );

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.Map_trip);
        mapFragment.getMapAsync(this);

        autoCompleteTextView = (AutoCompleteTextView)findViewById( R.id.Actv1);
        autoCompleteTextView2 = (AutoCompleteTextView)findViewById( R.id.Actv2 );

        autoCompleteTextView.setThreshold(1);
        autoCompleteTextView2.setThreshold(2);

        ButnTrip = (Button)findViewById( R.id.BtnTrip );
      //  ShowMap = (Button)findViewById( R.id.ShowMap );
       // Result = (TextView)findViewById( R.id.result );

        im1 = (ImageView)findViewById( R.id.im1 );
        im2 = (ImageView)findViewById( R.id.im2 );

        coder = new Geocoder( TrippPlanner.this );

        Source = new ArrayList<>();
        Source.add( "Gabtoli" );
        Source.add( "Shyamoli" );
        Source.add( "Mirpur Sony Cinema Hall" );
        Source.add( "Mirpur-10" );
        Source.add( "Mirpur-12" );
        Source.add( "Mohakhali Bus Stop" );


        Destination = new ArrayList <>();



        ArrayAdapter<String>adapter = new ArrayAdapter <String>(this,android.R.layout.simple_dropdown_item_1line,Source);
        autoCompleteTextView.setAdapter( adapter );

        ArrayAdapter<String>adapter1 = new ArrayAdapter <String>(this,android.R.layout.simple_dropdown_item_1line,Destination);
        autoCompleteTextView2.setAdapter( adapter1 );



        im1.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                autoCompleteTextView.showDropDown();
            }
        } );

        im2.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                autoCompleteTextView2.showDropDown();
            }
        } );


       autoCompleteTextView.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public
            void onItemClick(AdapterView <?> parent, View view, int position, long id) {
                selection = (String) parent.getItemAtPosition( position );

                if ((Source.get(0).toString()).equals( selection )) {
                    Destination.clear();
                    Destination.add( "Mirpur-2" );
                    Destination.add( "Mirpur-10" );
                    Destination.add( "Kalshi Bus Stand" );
                    Destination.add( "Jamuna Future Park" );
                    Destination.add( "Notun Bazaar Bus Stand" );
                    Destination.add( "Badda" );


                }
                else if ((Source.get(1).toString()).equals( selection )){
                    Destination.clear();



                    Destination.add( "Agargaon" );
                    Destination.add( "Mirpur-10" );
                    Destination.add( "Kalshi Bus Stand" );
                    Destination.add( "Bisshoroad" );
                    Destination.add( "Mirpur-2" );
                    Destination.add( "Mirpur-1" );
                    Destination.add( "Uttora" );


                }
                else if ((Source.get( 2 ).toString()).equals( selection )) {


                    Destination.clear();


                    Destination.add( "Mirpur-10" );
                    Destination.add( "Kazipara" );
                    Destination.add( "Shewrapara" );
                    Destination.add( "Mohakhali" );
                    Destination.add( "Gulshan1" );
                    Destination.add( "Badda" );
                    Destination.add( "Rampura" );
                    Destination.add( "Banasree" );

                }else if ((Source.get( 3 ).toString()).equals( selection )) {
                    Destination.clear();



                    Destination.add( "Banani" );
                    Destination.add( "Notun bazar" );
                    Destination.add( "Agargoan" );
                    Destination.add( "Farmgate Bus Stop" );
                    Destination.add( "Shahbag" );
                    Destination.add( "Motijheel Bus Stop" );
                    Destination.add( "Kazipara" );
                    Destination.add( "Shewrapara" );
                    Destination.add( "Mohakhali" );
                    Destination.add( "Gulshan1" );
                    Destination.add( "Badda" );
                    Destination.add( "Rampura" );
                    Destination.add( "Banasree" );


                }else if ((Source.get( 4 ).toString()).equals( selection )){
                    Destination.clear();


                    Destination.add( "Mirpur-10" );
                    Destination.add( "Agargoan" );
                    Destination.add( "Farmgate Bus Stop" );
                    Destination.add( "Shahbag" );
                    Destination.add( "Motijheel Bus Stop" );

                } else if ((Source.get( 5 ).toString()).equals( selection )){
                    Destination.clear();


                    Destination.add( "Kolabagan" );
                    Destination.add( "Karwan bazar" );
                    Destination.add( "Nabisco Bus Stop" );
                    Destination.add( "Mohakhali" );
                    Destination.add( "Gulshan 1" );
                    Destination.add( "Badda Link Road" );
                    Destination.add( "Kuril Bisso Road" );

                }


            }
            });


        ButnTrip.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                String s = autoCompleteTextView.getText().toString();
                String s1 = autoCompleteTextView2.getText().toString();
                df2 = new DecimalFormat( ".##" );

                try {
                    address = coder.getFromLocationName( s, 1 );
                    address1 = coder.getFromLocationName( s1, 1 );
                    location = address.get(0);
                    location1 = address1.get(0);
                    lat = location.getLatitude();
                    lng = location.getLongitude();
                    lat1 = location1.getLatitude();
                    lng1 = location1.getLongitude();
                   // Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                } catch (IOException e) {
                    e.printStackTrace();
                }
                double dsst = distances( lat, lng, lat1, lng1 );

                double kmph = 7.05;

                double duration = round( kmph * dsst );

                fare = basefare*dsst;

               // Result.setText("Distance: "+df2.format(dsst)+"Km"+"\n"+"Duration: "+duration+"min");

                CookieBar.build(TrippPlanner.this)
                        .setTitle("Trip Planner")
                        .setTitleColor(R.color.input_login)
                        .setDuration(4000)
                        .setLayoutGravity( Gravity.BOTTOM)
                        .setIcon(R.drawable.ic_directions_bus_black_24dp)
                        .setBackgroundColor(R.color.bg_main)
                        .setMessage("Distance: "+df2.format(dsst)+" Km"+"\n"+"Duration: "+duration+" min"+"\n"+"Fare: "+round(fare)+" Taka")
                        .setMessageColor(R.color.input_login)
                        .setActionColor(R.color.input_login)
                        .setAction("Ok", new OnActionClickListener() {
                            @Override
                            public void onClick() {

                            }
                        })
                        .show();


                mMap.clear();
                LatLng latLng = new LatLng(lat,lng);
                mMap.addMarker(new MarkerOptions().position(latLng).title("Source").icon( BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_BLUE ) ));

                LatLng latLng1 = new LatLng(lat1,lng1);
                mMap.addMarker(new MarkerOptions().position(latLng1).title("Destination"));

                mMap.animateCamera( CameraUpdateFactory.zoomTo( 10) );
            }
        } );



    }

    private double distances(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;
        // double km = dist/1;

        return dist; // output distance, in MILES
    }


    @Override
    public
    boolean onNavigationItemSelected(@NonNull MenuItem item) {
        return false;
    }

    @Override
    public
    void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public
    void onConnectionSuspended(int i) {

    }

    @Override
    public
    void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public
    void onLocationChanged(Location location) {

    }

    @Override
    public
    void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        try
        {
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.mapstyle1));

            if(!success){
                Log.e("BusStop", "Style parsing failed");
            }
        }
        catch(Resources.NotFoundException e){
            Log.e("BusStop", "Can't find style Error: ", e);

        }
        LatLng llp = new LatLng(23.6850, 90.3563);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(llp));
        mMap.animateCamera( CameraUpdateFactory.zoomTo( 10) );
        //Initialize Google Play Services
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission( this,
                    Manifest.permission.ACCESS_FINE_LOCATION )
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled( true );
            }
        } else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled( true );
        }



    }

    protected synchronized void buildGoogleApiClient(){
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi( LocationServices.API)
                .build();
        mGoogleApiClient.connect();
    }
}
