package com.example.abrar.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import java.util.HashMap;
import java.util.Calendar;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public
class feedback2 extends AppCompatActivity {

    private ImageButton FeedbackButton;
    private EditText Feedback;
    private RecyclerView Rl;
    private
    TextView tv;
    DatabaseReference dref,dreff;
    Query query;
    private String current_user_id;
    private FirebaseAuth auth;
    String email;
    // String F_id = dref.push().getKey();

    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_feedback2 );

        FeedbackButton = (ImageButton)findViewById( R.id.post_feedback_buuton );
        tv = (TextView)findViewById( R.id.textView3 );
        dref = FirebaseDatabase.getInstance().getReference("feedback");
        dreff = FirebaseDatabase.getInstance().getReference().child( "feedback" );
        Feedback = (EditText)findViewById( R.id.Comment_input );
        Rl = (RecyclerView)findViewById( R.id.recyclerview );
        Rl.setHasFixedSize( true );
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager( this );
        linearLayoutManager.setReverseLayout( true );
        linearLayoutManager.setStackFromEnd( true );
        Rl.setLayoutManager( linearLayoutManager );


        // auth = FirebaseAuth.getInstance();
        //current_user_id = auth.getCurrentUser().getUid();
       // email = getIntent().getStringExtra("Email");

       /* query = FirebaseDatabase.getInstance().getReference("History")
                .orderByChild("email")
                .equalTo(email);*/


        FeedbackButton.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {

              /*  dref.addListenerForSingleValueEvent( new ValueEventListener() {
                    @Override
                    public
                    void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()){
                            String Fdbk = Feedback.getText().toString();

                            if(!TextUtils.isEmpty(Fdbk)){

                              String username = dataSnapshot.child( "email" ).getValue().toString();
                                HashMap map = new HashMap(  );
                                map.put( "Feedback",Fdbk);
                                dref.updateChildren(map);
                            }
                            else {
                                Toast.makeText( getApplicationContext(),"Please give some valuable feedback",Toast.LENGTH_LONG ).show();

                            }
                            Feedback.setText("");
                        }
                    }

                    @Override
                    public
                    void onCancelled(DatabaseError databaseError) {

                    }
                } );*/

                String Fdbk = Feedback.getText().toString();

                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                Calendar cal = Calendar.getInstance();
                final String CurrentDate = dateFormat.format( cal.getTime() );

                SimpleDateFormat TimeFormat = new SimpleDateFormat("HH:mm");
                Calendar time = Calendar.getInstance();

                final String Currenttime = TimeFormat.format( time.getTime() );

                if(!TextUtils.isEmpty(Fdbk)){

                    Fdbk feedback = new Fdbk(getIntent().getStringExtra("Email"), Fdbk,CurrentDate, Currenttime );
                    String F_id = dref.push().getKey();

                    dref.child(F_id).setValue(feedback);

                    Toast.makeText( getApplicationContext(),getIntent().getStringExtra("Email"),Toast.LENGTH_LONG ).show();
                    Toast.makeText( getApplicationContext(),"Feedback given",Toast.LENGTH_LONG ).show();

                }
                else {
                    Toast.makeText( getApplicationContext(),"Please give some valuable feedback",Toast.LENGTH_LONG ).show();

                }
                Feedback.setText("");
            }

        } );

    }

    @Override
    protected
    void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Fdbk,FeedbackViewHolder> firebaseRecyclerAdapter = new FirebaseRecyclerAdapter <Fdbk, FeedbackViewHolder>(
                Fdbk.class,
                R.layout.activity_feedback_info,
                FeedbackViewHolder.class,
                dreff

        ) {
            @Override
            protected
            void populateViewHolder(FeedbackViewHolder viewHolder, Fdbk model, int position) {
                viewHolder.setEmail( model.getEmail() );
                viewHolder.setDescription( model.getDescription() );
                viewHolder.setDate( model.getDate() );
                viewHolder.setTime(model.getTime());


            }
        };
        Rl.setAdapter( firebaseRecyclerAdapter );
    }

    public static class FeedbackViewHolder extends RecyclerView.ViewHolder{
        View mview;

        public
        FeedbackViewHolder(View itemView) {
            super( itemView );
            mview = itemView;

        }
        public void setDescription(String description) {
            TextView feedbackk = (TextView)mview.findViewById( R.id.simple_text );
            feedbackk.setText( description );
        }
        public void setEmail(String Email) {
            TextView feedbackk_email = (TextView)mview.findViewById( R.id.user_ );
            feedbackk_email.setText( Email );
        }
        public void setDate(String date) {
            TextView feedbackk_date = (TextView)mview.findViewById( R.id.dates);
            feedbackk_date.setText( date);
        }

        public  void setTime(String time){
            TextView feedbackk_time = (TextView)mview.findViewById( R.id.times);
            feedbackk_time.setText( time);
        }
    }
}

