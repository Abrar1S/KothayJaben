package com.example.abrar.test1;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.internal.NavigationMenuItemView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ZoomControls;

import java.io.IOException;
import java.text.DateFormat;

import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseAuth;
import com.example.abrar.test1.POJO.Examples;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DatabaseReference;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.location.places.ui.PlaceSelectionListener;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.ValueEventListener;

import org.aviran.cookiebar2.CookieBar;
import org.aviran.cookiebar2.OnActionClickListener;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static java.lang.Math.round;

public class BusStop extends AppCompatActivity implements OnMapReadyCallback,NavigationView.OnNavigationItemSelectedListener,GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener,LocationListener,  GoogleMap.OnMarkerClickListener,
        GoogleMap.OnMarkerDragListener {

    private GoogleMap mMap;
    private GoogleMap mMap1;
    double latitude;
    double longitude;
    private int PROXIMITY_RADIUS = 1005;
    GoogleApiClient mGoogleApiClient;
    Location mLastLocation;
    Marker mCurrLocationMarker;
    LocationRequest mLocationRequest;
    ZoomControls zoom;
    private DrawerLayout mDrawer;
    private ActionBarDrawerToggle mToggle;
    LatLng origin;
    LatLng dest;
    ArrayList<LatLng> MarkerPoints;
    TextView ShowDistanceDuration;
    Polyline line;
    double end_latitude, end_longitude;
    double latt,longg;
    private Button mReqst,type;
    private LatLng pickupLocation;
    private Boolean requestBol = false;
    private Marker pickupMarker;
    private LatLng destinationLatLng;
    private Marker mDestinationMarker;
    AlertDialog alertDialogRadio;
    int mapChooser = 0;
    int mapCounter = 0;
    private LatLng latLng;
    private double latsnd;
    private  double lngstnd;
    private DecimalFormat df2;
    double basefare = 1.8;
    DatabaseReference dref;
    Button Ok;
    TextView text;


    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_bus_stop );


        //ShowDistanceDuration = (TextView) findViewById(R.id.show_distance_time);

        //     ShowDistanceDuration = (TextView) findViewById( R.id.show_distance_time );

        mDrawer = (DrawerLayout) findViewById(R.id.drawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawer, R.string.Open, R.string.CLose);
        mDrawer.addDrawerListener(mToggle);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        NavigationView navigationView = (NavigationView)findViewById(R.id.navigation_view);
        navigationView.setNavigationItemSelectedListener(BusStop.this);

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkLocationPermission();
        }
        MarkerPoints = new ArrayList<>();

        //show error dialog if Google Play Services not available
        if (!isGooglePlayServicesAvailable()) {
            Log.d( "onCreate", "Google Play Services not available. Ending Test case." );
            finish();
        } else {
            Log.d( "onCreate", "Google Play Services available. Continuing." );
        }


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById( R.id.map );
        mapFragment.getMapAsync( this );

        zoom = (ZoomControls)findViewById(R.id.zcZoom);
        zoom.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });
        zoom.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });

        df2 = new DecimalFormat( ".##" );

        PlaceAutocompleteFragment autocompleteFragment = (PlaceAutocompleteFragment)
                getFragmentManager().findFragmentById(R.id.place_autocomplete_fragment);

        autocompleteFragment.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(Place place) {
                // TODO: Get info about the selected place.
                mMap.clear();
                String destination = place.getName().toString();
                destinationLatLng = place.getLatLng();


                mDestinationMarker = mMap.addMarker(new MarkerOptions().position(destinationLatLng).title("Destination").icon(BitmapDescriptorFactory.fromResource( R.mipmap.ic_launcher_bus_stop_round)));
                mMap.moveCamera( CameraUpdateFactory.newLatLng( destinationLatLng ) );
                mMap.animateCamera( CameraUpdateFactory.zoomTo( 13 ) );
                double dss = distances( destinationLatLng.latitude,destinationLatLng.longitude, latitude, longitude );
                Double fare = basefare*dss;

                double kmph = 7.05;

                double duration = round( kmph * dss );


                LayoutInflater inflater = LayoutInflater.from(BusStop.this);
                View v = inflater.inflate(R.layout.custom_dialog2, null);

                final AlertDialog alertDialog = new AlertDialog.Builder(BusStop.this)
                        .setView(v)
                        .create();


                Ok = v.findViewById(R.id.ok);
                text = v.findViewById(R.id.text_view);



                Ok.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Toast.makeText(getApplicationContext(), " OK ", Toast.LENGTH_SHORT).show();
                        Geocoder myLocation = new Geocoder(BusStop.this, Locale.getDefault());
                        List<Address> myList = null;
                        List<Address> myList1 = null;
                        try {
                            myList = myLocation.getFromLocation(latitude,longitude, 1);
                            myList1 = myLocation.getFromLocation( destinationLatLng.latitude, destinationLatLng.longitude, 1 );
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Address address = (Address) myList.get(0);
                        String addressStr = "";
                        addressStr += address.getAddressLine(0);

                        Address address1 = (Address) myList1.get(0);
                        String addressStr1 = "";
                        addressStr1 += address1.getAddressLine(0);

                        DatabaseReference dref1 = FirebaseDatabase.getInstance().getReference().child("History");

                        DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        Calendar cal = Calendar.getInstance();

                        DateFormat TimeFormat = new SimpleDateFormat("HH:mm");
                        Calendar time = Calendar.getInstance();



                        String id = dref1.push().getKey();
                        dref1.child(id).child("date").setValue(dateFormat.format(cal.getTime()));
                        dref1.child(id).child("time").setValue(TimeFormat.format(time.getTime()));
                        dref1.child(id).child("email").setValue(getIntent().getExtras().getString("Email") );
                        dref1.child(id).child("end").setValue(addressStr1);
                        dref1.child( id ).child( "start" ).setValue( addressStr );
                        alertDialog.dismiss();

                    }
                });

                text.setText("Duration is "+ duration+" min and fare is "+round(fare)+" taka");
                alertDialog.show();



                mReqst.setText("Distance from bus is "+df2.format(dss)+" km");

            }
            @Override
            public void onError(Status status) {
                // TODO: Handle the error.
            }
        });
;

        mReqst = (Button)findViewById(R.id.distance);
        mReqst.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {

                if (requestBol){
                    endRide();


                }else {
                    requestBol = true;
                    String user_id = "driver1";
                    DatabaseReference reff = FirebaseDatabase.getInstance().getReference( "CustomerReqst" );

                    GeoFire geoFire = new GeoFire( reff );
                    geoFire.setLocation( user_id.toString(), new GeoLocation( mLastLocation.getLatitude(), mLastLocation.getLongitude() ) );

                    pickupLocation = new LatLng( mLastLocation.getLatitude(), mLastLocation.getLongitude() );
                    mMap.addMarker( new MarkerOptions().position( pickupLocation ).title( "user location" ) );
                    mReqst.setText( "Waiting for a bus" );
                    getClosestDriver();
                }
            }
        } );

    }

    private
    void endRide() {
        requestBol = false;
        geoQuery.removeAllListeners();
        driverLocationRef.removeEventListener(driverLocationRefListener);


        if (driverFoundID != null){
            DatabaseReference driverRef = FirebaseDatabase.getInstance().getReference().child("Drivers").child(driverFoundID);
            driverRef.removeValue();
            driverFoundID = null;

        }
        driverFound = false;
        radius = 1;

        String userId = "driver1";

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("CustomerReqst");
        GeoFire geoFire = new GeoFire(ref);
        geoFire.removeLocation(userId);

        if(pickupMarker != null){
            pickupMarker.remove();
        }
        if (mDriverMarker != null){
            mDriverMarker.remove();
        }
        if (mDestinationMarker != null){
            mDestinationMarker.remove();
        }
        mReqst.setText( "Looking for bus" );


    }

    private int radius = 1;
    private Boolean driverFound = false;
    private String driverFoundID;
    GeoQuery geoQuery;
    private void getClosestDriver() {
        DatabaseReference driverLocation = FirebaseDatabase.getInstance().getReference().child( "driversAvailable" );

        GeoFire geoFire = new GeoFire( driverLocation );
        geoQuery = geoFire.queryAtLocation( new GeoLocation( pickupLocation.latitude, pickupLocation.longitude ), radius );
        geoQuery.removeAllListeners();

        geoQuery.addGeoQueryEventListener( new GeoQueryEventListener() {
            @Override
            public
            void onKeyEntered(String key, GeoLocation location) {
                if (!driverFound && requestBol) {
                    driverFound = true;
                    driverFoundID = key;

                    DatabaseReference driverRef =  FirebaseDatabase.getInstance().getReference().child("Drivers").child(driverFoundID);
                    String customerId = "driver1";
                    HashMap map = new HashMap();
                    map.put("customerRideId", customerId);
                    driverRef.updateChildren(map);

                    getDriverLocation();
                    mReqst.setText("Looking for Driver Location....");
                }
            }



            @Override
            public
            void onKeyExited(String key) {

            }

            @Override
            public
            void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public
            void onGeoQueryReady() {
                if (!driverFound)
                {
                    radius++;
                    getClosestDriver();
                }
            }

            @Override
            public
            void onGeoQueryError(DatabaseError error) {

            }
        } );



    }
    private LatLng driverLatLng;
    private Marker mDriverMarker;
    private DatabaseReference driverLocationRef;
    private ValueEventListener driverLocationRefListener;
    private void getDriverLocation(){
        driverLocationRef = FirebaseDatabase.getInstance().getReference().child("driversAvailable").child("driver1").child("l");
        driverLocationRefListener =  driverLocationRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    List<Object> map = (List<Object>) dataSnapshot.getValue();
                    double locationLat = 0;
                    double locationLng = 0;
                    //   mReqst.setText("Driver Found");
                    if(map.get(0) != null){
                        locationLat = Double.parseDouble(map.get(0).toString());
                    }
                    if(map.get(1) != null){
                        locationLng = Double.parseDouble(map.get(1).toString());
                    }
                    //   Toast.makeText( getApplicationContext(), "Driver position: "  + locationLat + locationLng, Toast.LENGTH_SHORT).show();
                    driverLatLng = new LatLng(locationLat,locationLng);
                    if(mDriverMarker != null){
                        mDriverMarker.remove();
                    }
                    pickupMarker = mMap.addMarker(new MarkerOptions().position(driverLatLng).title("pickup location"));
                    df2 = new DecimalFormat( ".##" );



                    double dis = distances( driverLatLng.latitude,driverLatLng.longitude,pickupLocation.latitude,pickupLocation.longitude);

                    // int cnt = 0;


                    if (dis < .1)  {
                        /////distance in miles

                        mReqst.setText("Bus is here");

                    }
                    else{
                        mReqst.setText("Bus is "+df2.format(dis)+" km further Away " );

                        dref = FirebaseDatabase.getInstance().getReference("Bus1");
                        dref.addValueEventListener(new ValueEventListener() {
                            long count; int c=0;
                            @Override
                            public void onDataChange(DataSnapshot dataSnapshot) {
                                for(DataSnapshot ds: dataSnapshot.getChildren()){

                                    count = ds.getChildrenCount();
                                    c++;

                                }
                                //   Toast.makeText(getApplicationContext(),"p: " + count + "c: " + c, Toast.LENGTH_SHORT).show();
                                int s = 40-c;
                                CookieBar.build(BusStop.this)
                                        .setTitle("Hello Passenger")
                                        .setTitleColor(R.color.input_login)
                                        .setDuration(4000)
                                        .setLayoutGravity(Gravity.BOTTOM)
                                        .setIcon(R.drawable.ic_people_black_24dp)
                                        .setBackgroundColor(R.color.bg_main)
                                        .setMessage( s + " Approx available seat")
                                        .setMessageColor(R.color.input_login)
                                        .setActionColor(R.color.input_login)
                                        .setAction("Ok", new OnActionClickListener() {
                                            @Override
                                            public void onClick() {

                                            }
                                        })
                                        .show();

                                c=0;
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });


                    }

                    mDriverMarker = mMap.addMarker(new MarkerOptions().position(driverLatLng).title("your bus").icon(BitmapDescriptorFactory.fromResource( R.mipmap.ic_launcher_o_bus_round)));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }


    @Override
    public
    void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        try
        {
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.mapstyle1));

            if(!success){
                Log.e("BusStop", "Style parsing failed");
            }
        }
        catch(Resources.NotFoundException e){
            Log.e("BusStop", "Can't find style Error: ", e);

        }

        //Initialize Google Play Services
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission( this,
                    Manifest.permission.ACCESS_FINE_LOCATION )
                    == PackageManager.PERMISSION_GRANTED) {
                buildGoogleApiClient();
                mMap.setMyLocationEnabled( true );
            }
        } else {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled( true );
        }




        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng point) {
                mMap.clear();
                latt = point.latitude;
                longg = point.longitude;

                df2 = new DecimalFormat( ".##" );
                MarkerOptions options = new MarkerOptions();


                // Setting the position of the marker
                options.position(point);


                mMap.addMarker( options.icon( BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_BLUE ) ) );


                if(driverFound) {
                    mMap.addMarker( options.icon( BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_GREEN ) ) );

                    double dsst = distances( latt, longg, driverLatLng.latitude, driverLatLng.longitude );

                    double kmph = 7.05;

                    double duration = round( kmph * dsst );


                    LayoutInflater inflater = LayoutInflater.from(BusStop.this);
                    View v = inflater.inflate(R.layout.custom_dialog2, null);

                    final AlertDialog alertDialog = new AlertDialog.Builder(BusStop.this)
                            .setView(v)
                            .create();


                    Ok = v.findViewById(R.id.ok);
                    text = v.findViewById(R.id.text_view);

                    text.setText(duration + " in Min" );

                    Ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            alertDialog.dismiss();

                        }
                    });


                    alertDialog.show();





                }else{
                    double ds = distances( latt, longg, mLastLocation.getLatitude(), mLastLocation.getLongitude() );


                    LayoutInflater inflater = LayoutInflater.from(BusStop.this);
                    View v = inflater.inflate(R.layout.custom_dialog2, null);

                    final AlertDialog alertDialog = new AlertDialog.Builder(BusStop.this)
                            .setView(v)
                            .create();


                    Ok = v.findViewById(R.id.ok);
                    text = v.findViewById(R.id.text_view);

                    text.setText( df2.format(ds) + "Distance in KM" );

                    Ok.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            alertDialog.dismiss();

                        }
                    });


                    alertDialog.show();



                }





            }


        });

        Button btnbusStop = (Button) findViewById( R.id.findBustStop );
        btnbusStop.setOnClickListener( new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {



                build_retrofit_and_get_response( "bus_station" );
            }
        } );


    }


    private
    void build_retrofit_and_get_response(String type) {
        String url = "https://maps.googleapis.com/maps/";

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl( url )
                .addConverterFactory( GsonConverterFactory.create() )
                .build();

        df2 = new DecimalFormat( ".##" );
        RetrofitMaps service = retrofit.create( RetrofitMaps.class );



        Call <Examples> call = service.getNearbyPlaces( type, latitude + "," + longitude, PROXIMITY_RADIUS );



        call.enqueue( new Callback <Examples>() {
            @Override
            public
            void onResponse(Call <Examples> call, Response <Examples> response) {
                double  distances = 0.0 ;
                String placeName = "";
                String vicinity = "";

                try {
                    mMap.clear();
                    for (int i = 0; i < response.body().getResults().size(); i++) {
                        double lat = response.body().getResults().get( i ).getGeometry().getLocation().getLat();
                        double lng = response.body().getResults().get( i ).getGeometry().getLocation().getLng();
                        placeName = response.body().getResults().get( i ).getName();
                        vicinity = response.body().getResults().get( i ).getVicinity();
                        MarkerOptions markerOptions = new MarkerOptions();

                        distances = distances(lat, lng, latitude, longitude);


                        if (distances < 0.1)  {



                            LayoutInflater inflater = LayoutInflater.from(BusStop.this);
                            View v = inflater.inflate(R.layout.custom_dialog2, null);

                            final AlertDialog alertDialog = new AlertDialog.Builder(BusStop.this)
                                    .setView(v)
                                    .create();


                            Ok = v.findViewById(R.id.ok);
                            text = v.findViewById(R.id.text_view);

                            text.setText( df2.format(distances)+" is the nearest bus stoppage from you" );

                            Ok.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    alertDialog.dismiss();

                                }
                            });


                            alertDialog.show();


                        }


                        else {

                        }

                        latLng = new LatLng( lat, lng );

                        mMap.addMarker(markerOptions.position(latLng).title("Stoppage").icon(BitmapDescriptorFactory.fromResource( R.mipmap.ic_launcher_traffic_t_round)) );
                        mMap.moveCamera( CameraUpdateFactory.newLatLng( latLng ) );
                        mMap.animateCamera( CameraUpdateFactory.zoomTo( 15 ) );
                    }



                } catch (Exception e) {
                    Log.d( "onResponse", "There is an error" );
                    e.printStackTrace();
                }
            }

            @Override
            public
            void onFailure(Call <Examples> call, Throwable t) {

            }
        } );


    }


    private double distances(double lat1, double lng1, double lat2, double lng2) {

        double earthRadius = 6371; // in miles, change to 6371 for kilometer output

        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);

        double sindLat = Math.sin(dLat / 2);
        double sindLng = Math.sin(dLng / 2);

        double a = Math.pow(sindLat, 2) + Math.pow(sindLng, 2)
                * Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2));

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

        double dist = earthRadius * c;
        // double km = dist/1;

        return dist; // output distance, in MILES
    }



    private
    boolean isGooglePlayServicesAvailable() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable( this );
        if (result != ConnectionResult.SUCCESS) {
            if (googleAPI.isUserResolvableError( result )) {
                googleAPI.getErrorDialog( this, result,
                        0 ).show();
            }
            return false;
        }
        return true;
    }


    protected synchronized
    void buildGoogleApiClient() {
        mGoogleApiClient = new GoogleApiClient.Builder( this )
                .addConnectionCallbacks( this )
                .addOnConnectionFailedListener( this )
                .addApi( LocationServices.API )
                .build();
        mGoogleApiClient.connect();
    }

    @SuppressLint("RestrictedApi")
    @Override
    public
    void onConnected(@Nullable Bundle bundle) {
        mLocationRequest = new LocationRequest();
        mLocationRequest.setInterval( 10000 );
        mLocationRequest.setFastestInterval( 10000 );
        mLocationRequest.setPriority( LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY );
        if (ContextCompat.checkSelfPermission( this,
                Manifest.permission.ACCESS_FINE_LOCATION )
                == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates( mGoogleApiClient, mLocationRequest, this );
        }
    }

    @Override
    public
    void onConnectionSuspended(int i) {

    }

    @Override
    public
    void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }



    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    public
    boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission( this,
                Manifest.permission.ACCESS_FINE_LOCATION )
                != PackageManager.PERMISSION_GRANTED) {

            // Asking user if explanation is needed
            if (ActivityCompat.shouldShowRequestPermissionRationale( this,
                    Manifest.permission.ACCESS_FINE_LOCATION )) {


                //Prompt the user once explanation has been shown
                ActivityCompat.requestPermissions( this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION );


            } else {
                // No explanation needed, we can request the permission.
                ActivityCompat.requestPermissions( this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION );
            }
            return false;
        } else {
            return true;
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }

        return super.onOptionsItemSelected(item);

    }
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        if (mGoogleApiClient == null) {
                            buildGoogleApiClient();
                        }
                        mMap.setMyLocationEnabled(true);
                    }

                } else {

                    // Permission denied, Disable the functionality that depends on this permission.
                    Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                }
                return;
            }

        }
    }

    @Override
    public
    void onLocationChanged(Location location) {
        Log.d("onLocationChanged", "entered");
        if(getApplicationContext()!=null) {
            mLastLocation = location;
            if (mCurrLocationMarker != null) {
                mCurrLocationMarker.remove();
            }

            latitude = location.getLatitude();
            longitude = location.getLongitude();


            LatLng latLng = new LatLng( location.getLatitude(), location.getLongitude() );
            MarkerOptions markerOptions = new MarkerOptions();
            markerOptions.position( latLng );
            // markerOptions.draggable(true);
            markerOptions.title( "Current Position" );
            markerOptions.icon( BitmapDescriptorFactory.defaultMarker( BitmapDescriptorFactory.HUE_MAGENTA ) );
            mCurrLocationMarker = mMap.addMarker( markerOptions );

            //move map camera
            mMap.moveCamera( CameraUpdateFactory.newLatLng( latLng ) );
            mMap.animateCamera( CameraUpdateFactory.zoomTo( 15 ) );



            String user_id = "User2";

            DatabaseReference ref = FirebaseDatabase.getInstance().getReference( "UserPosition" );

            GeoFire geoFire = new GeoFire( ref );
            geoFire.setLocation( user_id.toString(), new GeoLocation( mLastLocation.getLatitude(), mLastLocation.getLongitude() ) );

        }

    }



    @Override
    public
    boolean onMarkerClick(Marker marker) {
        marker.setDraggable(true);
        return false;
    }

    @Override
    public
    void onMarkerDragStart(Marker marker) {

    }

    @Override
    public
    void onMarkerDrag(Marker marker) {

    }

    @Override
    public
    void onMarkerDragEnd(Marker marker) {
        end_latitude = marker.getPosition().latitude;
        end_longitude =  marker.getPosition().longitude;

        Log.d("end_lat",""+end_latitude);
        Log.d("end_lng",""+end_longitude);
    }
    public void displayAlertMessage(String message,  DialogInterface.OnClickListener listener)
    {
        new AlertDialog.Builder(BusStop.this)
                .setMessage(message)
                .setPositiveButton("Ok", listener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }




    @Override
    public
    boolean onNavigationItemSelected(@NonNull MenuItem item) {

        UPInfo info = new UPInfo();
        info.setEmail( getIntent().getExtras().getString("Email") );

        int id = item.getItemId();

        if(id == R.id.db){

            Intent intent = new Intent(BusStop.this, route_list.class);
            Toast.makeText(BusStop.this, "Route Information", Toast.LENGTH_SHORT).show();
            startActivity(intent);
            //finish();

        }
        if(id == R.id.calculation){

            Intent intent = new Intent(BusStop.this, FareCalculator.class);
            Toast.makeText(BusStop.this, "Manual Calculator", Toast.LENGTH_SHORT).show();
            startActivity(intent);
            //finish();

        }

        if(id == R.id.Map){

            // mToggle = new ActionBarDrawerToggle(this, mDrawer, R.string.Open, R.string.CLose);

            MapStyle();


        }
        if(id == R.id.event){

            Intent intent = new Intent(BusStop.this, Offer_list.class);
            intent.putExtra("Email",getIntent().getExtras().getString("Email") );

            Toast.makeText(BusStop.this, "Offer Information", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }

        if(id == R.id.scan){

            Intent intent = new Intent(BusStop.this, QrCodeGenerator.class);
            intent.putExtra("Email", getIntent().getExtras().getString("Email"));
            startActivity(intent);
            //finish();
        }

        if(id == R.id.about){

            Intent intent = new Intent(BusStop.this, just.class);
            intent.putExtra("Email", getIntent().getExtras().getString("Email"));
            startActivity(intent);
            //finish();
        }
        if(id == R.id.logout){
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(BusStop.this, Login.class));
            finish();
            Toast.makeText(BusStop.this, "Logout", Toast.LENGTH_SHORT).show();
        }
        return false;
    }

    public void MapStyle(){


        CharSequence[] value = {"Mapstyle 1", "Mapstyle 2","Mapstyle 3"};

        AlertDialog.Builder builder = new AlertDialog.Builder(BusStop.this);
        builder.setTitle("Choose map type");

        builder.setSingleChoiceItems(value, mapChooser, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int item) {


                if( item == 0) {


                    mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(BusStop.this, R.raw.mapstyle1));

                    mapChooser = 0;
                }
                else if (item == 1) {

                    mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(BusStop.this, R.raw.mapstyle2));

                    mapChooser = 1;
                }

                else if (item == 2) {

                    mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(BusStop.this, R.raw.mapstyle));

                    mapChooser = 2;
                }


                else {

                }

                alertDialogRadio.dismiss();

            }
        });


        alertDialogRadio = builder.create();
        alertDialogRadio.show();

    }

}
