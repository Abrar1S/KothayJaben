package com.example.abrar.test1;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.regex.Pattern;

public class Signup extends AppCompatActivity {

    private static final Pattern PASSWORD_PATTERN =  Pattern.compile("^"+
            "(?=.*[0-9])"+
            "(?=.*[a-z])"+
            "(?=.*[A-Z])"+
            "(?=.*[#@@$%&+_=+])"+
            "(?=.\\S+$)"+
            ".{6,20}"+
            "$");

               // sdd = space, dot, or dash

    private TextInputLayout InputEmail,InputPass,InputName,InputPhn;
    private TextInputEditText inputEmail, inputPassword,inputName,inputPhn;     //hit option + enter if you on mac , for windows hit ctrl + enter
    private Button btnSignIn, btnSignUp, btnResetPassword;
    private ProgressBar progressBar;
    private FirebaseAuth auth;
    FirebaseDatabase db;
    DatabaseReference user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
       // db = FirebaseDatabase.getInstance();
        //user = db.getReference("Users");


        InputEmail = (TextInputLayout)findViewById( R.id.InputEmail );
        InputPass = (TextInputLayout)findViewById( R.id.InputPass );
        InputName = (TextInputLayout)findViewById( R.id.InputName );
        InputPhn = (TextInputLayout)findViewById( R.id.InputPhn);

        btnSignIn = (Button) findViewById(R.id.sign_in_button);
        btnSignUp = (Button) findViewById(R.id.sign_up_button);
        inputName = (TextInputEditText) findViewById(R.id.name);
        inputEmail = (TextInputEditText) findViewById(R.id.email);
        inputPassword = (TextInputEditText) findViewById(R.id.password);
        inputPhn = (TextInputEditText) findViewById(R.id.phn);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
       // btnResetPassword = (Button) findViewById(R.id.btn_reset_password);

      /*  btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Signup.this, Resett.class));
            }
        });*/

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String email = inputEmail.getText().toString().trim();
                final String password = inputPassword.getText().toString().trim();
                final String name = inputName.getText().toString().trim();
                final String phone = inputPhn.getText().toString().trim();

                if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password) || TextUtils.isEmpty(password)) {
                    inputEmail.setError( "Fields Can't be empty" );
                    //Toast.makeText(getApplicationContext(), "You Did not fill All the Fields!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    inputEmail.setError( "Please enter valid Email Address" );
                }

                else if (phone.length()!=11) {
                    Toast.makeText(getApplicationContext(), "11 Digit is eligible!", Toast.LENGTH_SHORT).show();
                    return;
                }
                else if(!PASSWORD_PATTERN.matcher( password ).matches()){
                    inputPassword.setError( "Password too weak" );
                }
                /*else if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }*/

                progressBar.setVisibility(View.VISIBLE);



                //create user
                auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                              //  Toast.makeText(Signup.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.

                                   /* String user_id = auth.getCurrentUser().getUid();
                                    DatabaseReference current_user_db = FirebaseDatabase.getInstance().getReference().child("Users").child("Customers").child(user_id);
                                    current_user_db.setValue(true);
                                    startActivity(new Intent(Signup.this, Login.class));
                                    finish();*/

                                   if(task.isSuccessful()){
                                   User users = new User(name,email,password,phone);
                                   FirebaseDatabase.getInstance().getReference("Users").child( FirebaseAuth.getInstance().getCurrentUser().getUid() ).setValue(users).addOnCompleteListener( new OnCompleteListener <Void>() {
                                       @Override
                                       public
                                       void onComplete(@NonNull Task <Void> task) {
                                           if(task.isSuccessful()) {

                                               Toast.makeText( Signup.this, "Authentication SuccessFull.",
                                                       Toast.LENGTH_SHORT ).show();
                                               startActivity( new Intent( Signup.this, Login.class ) );
                                               finish();
                                           }
                                           else{
                                               Toast.makeText(Signup.this, "Authentication Failed." ,
                                                       Toast.LENGTH_SHORT).show();
                                           }
                                       }
                                   } );
                                       String amount = "0";
                                       HashMap map = new HashMap();
                                       map.put("Amount", amount);
                                       FirebaseDatabase.getInstance().getReference("Users").child( FirebaseAuth.getInstance().getCurrentUser().getUid() ).updateChildren( map );
                                }
                                else{
                                       Toast.makeText(Signup.this, "Authentication Failed." ,
                                               Toast.LENGTH_SHORT).show();
                                   }
                            }
                        });

                      /*  auth.createUserWithEmailAndPassword( inputEmail.getText().toString(),inputPassword.getText().toString())
                        .addOnSuccessListener( new OnSuccessListener <AuthResult>() {
                            @Override
                            public
                            void onSuccess(AuthResult authResult) {
                                User users = new User(name,email,password,phone);

                                users.setEmail(inputEmail.getText().toString());
                                users.setPassword( inputPassword.getText().toString() );
                                user.child( auth.getInstance().getCurrentUser().getUid())
                                    .setValue(users)
                                    .addOnSuccessListener( new OnSuccessListener <Void>() {
                                        @Override
                                        public
                                        void onSuccess(Void aVoid) {
                                            Toast.makeText(Signup.this, "Authentication SuccessFull." ,
                                                    Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(Signup.this, Login.class));
                                            finish();
                                        }
                                    } )
                                    .addOnFailureListener( new OnFailureListener() {
                                    @Override
                                    public
                                    void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Signup.this, "Authentication Failed." ,
                                                Toast.LENGTH_SHORT).show();
                                    }
                                } );

                            }
                        } )
                .addOnFailureListener( new OnFailureListener() {
                    @Override
                    public
                    void onFailure(@NonNull Exception e) {
                        Toast.makeText(Signup.this, "Authentication Failed." ,
                                Toast.LENGTH_SHORT).show();
                    }
                } );*/

            }
        });
    }




    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }
}
