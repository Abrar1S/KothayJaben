package com.example.abrar.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public
class TripPlanner extends AppCompatActivity  {


    AutoCompleteTextView autoCompleteTextView,autoCompleteTextView2;
    Spinner spinner;
    Button exchange;
    ArrayList<String>Source ;
    ArrayList<String>Destination;
    ArrayList<String>Destination1;
    List<Address> address;
    List<Address> address1;
    Geocoder coder,coder1;
    Address location, location1;
    double lat,lng, lat1, lng1;
    String selection,selection1 = null;
    int c = 0;


    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_trip_planner );

        Source = new ArrayList <>();
        Source.add( "Gabtoli" );
        Source.add( "Shyamoli" );
        Source.add( "Mirpur Sony Cinema Hall" );
        Source.add( "Mirpur-10" );
        Source.add( "Mirpur-12" );
        Source.add( "Azimpur" );

        coder = new Geocoder( TripPlanner.this );

        exchange = (Button)findViewById( R.id.button2);

        autoCompleteTextView = (AutoCompleteTextView) findViewById( R.id.Autocomplete );
        spinner = (Spinner) findViewById( R.id.spinner );

        ArrayAdapter <String> adapter = new ArrayAdapter <String>( this, android.R.layout.simple_list_item_1, Source );
        autoCompleteTextView.setAdapter( adapter );



        // Destination1 = new ArrayList <>();

        Destination = new ArrayList <>();
        Destination.add( "See Stoppage" );
        autoCompleteTextView.setOnItemClickListener( new AdapterView.OnItemClickListener() {
                                                         @Override
                                                         public
                                                         void onItemClick(AdapterView <?> parent, View view, int position, long id) {

                                                             selection = (String) parent.getItemAtPosition( position );

                                                             if ((Source.get(0).toString()).equals( selection )) {



                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );

                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                     c=1;
                                                                     Toast.makeText( getApplicationContext(), "" + "ami onclick e asi " + c , Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }
                                                                 Destination.clear();

                                                                 Destination.add( "Mirpur-2" );
                                                                 Destination.add( "Mirpur-10" );
                                                                 Destination.add( "Kalshi" );
                                                                 Destination.add( "Jamuna Future Park" );
                                                                 Destination.add( "Natun Bazar" );
                                                                 Destination.add( "Badda" );

                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 0 ), Toast.LENGTH_SHORT ).show();

                                                                 try {
                                                                     address = coder.getFromLocationName( Destination.get( 0 ), 1 );
                                                                     location1 = address.get( 0 );
                                                                     lat1 = location1.getLatitude();
                                                                     lng1 = location1.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat1 + "," + lng1, Toast.LENGTH_SHORT ).show();

                                                                 }catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }



                                                             } else if ((Source.get(1).toString()).equals( selection )) {



                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );
                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }

                                                                 Destination.clear();


                                                                 Destination.add( "Shiya Mashjid" );
                                                                 Destination.add( "Agargaon" );
                                                                 Destination.add( "MIrpur-10" );
                                                                 Destination.add( "Kalshi" );
                                                                 Destination.add( "Bisshoroad" );
                                                                 Destination.add( "Airport" );
                                                                 Destination.add( "Uttora" );
                                                                 Destination.add( "Abdullahpur" );

                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 1 ), Toast.LENGTH_SHORT ).show();


                                                             } else if ((Source.get( 2 ).toString()).equals( selection )) {



                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );
                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }

                                                                 Destination.clear();


                                                                 Destination.add( "Mirpur-10" );
                                                                 Destination.add( "Kazipara" );
                                                                 Destination.add( "Shewrapara" );
                                                                 Destination.add( "Mohakhali" );
                                                                 Destination.add( "Gulshan1" );
                                                                 Destination.add( "Badda" );
                                                                 Destination.add( "Rampura" );
                                                                 Destination.add( "Banasree" );

                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 2 ), Toast.LENGTH_SHORT ).show();


                                                             } else if ((Source.get( 3 ).toString()).equals( selection )) {




                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );
                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }
                                                                 Destination.clear();


                                                                 Destination.add( "Cantonment" );
                                                                 Destination.add( "Banani" );
                                                                 Destination.add( "Notun bazar" );
                                                                 Destination.add( "Agargoan" );
                                                                 Destination.add( "Farmgate" );
                                                                 Destination.add( "Shahbag" );
                                                                 Destination.add( "Motijhil" );
                                                                 Destination.add( "Kazipara" );
                                                                 Destination.add( "Shewrapara" );
                                                                 Destination.add( "Mohakhali" );
                                                                 Destination.add( "Gulshan1" );
                                                                 Destination.add( "Badda" );
                                                                 Destination.add( "Rampura" );
                                                                 Destination.add( "Banasree" );


                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 3 ), Toast.LENGTH_SHORT ).show();


                                                             } else if ((Source.get( 4 ).toString()).equals( selection )) {


                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );
                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }

                                                                 Destination.clear();


                                                                 Destination.add( "Mirpur-10" );
                                                                 Destination.add( "Agargoan" );
                                                                 Destination.add( "Farmgate" );
                                                                 Destination.add( "Shahbag" );
                                                                 Destination.add( "Motijhil" );


                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 4 ), Toast.LENGTH_SHORT ).show();


                                                             } else if ((Source.get( 5 ).toString()).equals( selection )) {



                                                                 try {
                                                                     address = coder.getFromLocationName( selection, 1 );
                                                                     location = address.get( 0 );
                                                                     lat = location.getLatitude();
                                                                     lng = location.getLongitude();
                                                                     Toast.makeText( getApplicationContext(), "" + lat + "," + lng, Toast.LENGTH_SHORT ).show();

                                                                 } catch (IOException e) {
                                                                     e.printStackTrace();
                                                                 }

                                                                 Destination.clear();


                                                                 Destination.add( "Kolabagan" );
                                                                 Destination.add( "Karwan bazar" );
                                                                 Destination.add( "Nabisco" );
                                                                 Destination.add( "Mohakhali" );
                                                                 Destination.add( "Gulshan 1" );
                                                                 Destination.add( "Badda Link Road" );
                                                                 Destination.add( "Kuril Bisso Road" );

                                                                 Toast.makeText( getApplicationContext(), "" + Source.get( 5 ), Toast.LENGTH_SHORT ).show();

                                                             }

                                                             // Toast.makeText( getApplicationContext(), " " + lat + lng , Toast.LENGTH_LONG ).show();


                                                         }
                                                     }


        );




        ArrayAdapter <String> adapter1 = new ArrayAdapter <String>( this, android.R.layout.simple_list_item_1, Destination );
        // adapter1.setDropDownViewResource( android.R.layout.simple_dropdown_item_1line );
        spinner.setAdapter( adapter1 );


        spinner.setOnItemSelectedListener( new AdapterView.OnItemSelectedListener() {
            @Override
            public
            void onItemSelected(AdapterView <?> parent, View view, int position, long id) {
                //Destination = new ArrayList <>();
                // Destination.add( "destination" );
                selection1 = (String) parent.getItemAtPosition( position );
                Toast.makeText( getApplicationContext(), " " + selection1, Toast.LENGTH_LONG ).show();


               /* if( c==1) {
                    Log.d("TripPlanner", "ami asi if condition ekhane");
                    Toast.makeText( getApplicationContext(), " " + "ami asi if condition ekhane", Toast.LENGTH_LONG ).show();
                    try {
                        Log.d("TripPlanner", "ami asi try e ");
                        Toast.makeText( getApplicationContext(), "" + "ami try  e asci" , Toast.LENGTH_SHORT ).show();
                        address1 = coder1.getFromLocationName( selection1, 5 );
                        location1 = address1.get( 0 );

                        lat1 = location1.getLatitude();
                        lng1 = location1.getLongitude();
                        Toast.makeText( getApplicationContext(), "" + lat1 + "," + lng1, Toast.LENGTH_SHORT ).show();


                    } catch (IOException e) {
                        Log.d("TripPlanner", "ami asi catch ekhane");
                        Toast.makeText( getApplicationContext(), "" + "ami catch e asci" , Toast.LENGTH_SHORT ).show();
                    }
                }

                Log.d("TripPlanner", "ami asi ekhane");
                Toast.makeText( getApplicationContext(), "" + "ami ses ekhane " + c , Toast.LENGTH_SHORT ).show();
                //Toast.makeText( getApplicationContext(), "" + "ami ses ekhane num =  " + c, Toast.LENGTH_SHORT ).show();


              /* String str;
                switch (position){
                    case 0:
                        str = "Destination";
                        Toast.makeText( getApplicationContext(),""+ "Destination",Toast.LENGTH_SHORT ).show();
                        break;
                    case 1:
                        str = Destination.get(0);
                        break;
                    case 2:
                        str = "Mirpur-1";
                        break;
                }

               // Toast.makeText( getApplicationContext(),""+ Destination1.get(0),Toast.LENGTH_SHORT ).show();*/



            }

            @Override
            public
            void onNothingSelected(AdapterView <?> parent) {
              /*  c=1;
                Log.d("TripPlanner", "AMI NAI");
                Toast.makeText( getApplicationContext(), "" + "AMI SES EBAR", Toast.LENGTH_SHORT ).show();*/
            }
        } );

    }

  /*  @Override
    public
    void onMapReady(GoogleMap googleMap) {

    }
    }*/
}
