package com.example.abrar.test1;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.abrar.test1.History_info;

import java.util.List;

public
class HistoryAdapter extends BaseAdapter {
    private
    Context mContexxt;
    private
    List<History_info>mHistory;


    public HistoryAdapter(Context mContexxt,List<History_info>mHistory){
        this.mContexxt = mContexxt;
        this.mHistory = mHistory;
    }

    @Override
    public
    int getCount() {
        return mHistory.size();
    }

    @Override
    public
    Object getItem(int position) {
        return mHistory.get(position);
    }

    @Override
    public
    long getItemId(int position) {
        return position;
    }

    @Override
    public
    View getView(int position, View convertView, ViewGroup parent) {
        View v = View.inflate( mContexxt,R.layout.activity_hisory_info,null );
        TextView tvemail = (TextView)v.findViewById( R.id.E_mail );
        /*TextView tvedate = (TextView)v.findViewById( R.id.D_date );
        TextView tvstart = (TextView)v.findViewById( R.id.S_start );
        TextView tvend = (TextView)v.findViewById( R.id.E_nd );*/


        tvemail.setText(// mHistory.get(position).getEmail()+
                mHistory.get( position ).getStart() +"\n"
                        + mHistory.get( position ).getEnd() +"\n"
                        + mHistory.get( position ).getDate() +"\n"
                        + mHistory.get( position ).getTime()
        );
        //tvedate.setText( mHistory.get(position).getDate() );
        //tvstart.setText( mHistory.get( position ).getStart() );
        //tvend.setText( mHistory.get( position ).getEnd() );



        return v;
    }
}

