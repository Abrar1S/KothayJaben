package com.example.abrar.test1;

public class ImageUploader {

    public String name;

    public String image_url;

    public ImageUploader(String url) {

        this.image_url = url;
    }

    public ImageUploader(){}

    public String getName() {
        return name;
    }

    public String getUrl() {
        return image_url;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUrl(String url) {
        this.image_url = url;
    }
}
