package com.example.abrar.test1;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.aviran.cookiebar2.CookieBar;
import org.aviran.cookiebar2.OnActionClickListener;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Fare_list extends AppCompatActivity {

    ListView listView;
    FirebaseDatabase database;
    DatabaseReference dref, dref1, dref2;
    ArrayList<String> list;
    ArrayAdapter<String> adapter;
    information fare;

    fare_adapter adapter1;
    private List<information> fare1;
    String key;
    String[] Pack;
    UPInfo info = new UPInfo();

    String email;
    Dialog myDialog;
    Button Ok, Cancel;
    TextView text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fare_list);

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        setDataToView(user);


        //Toast.makeText(getApplicationContext(), info.getEmail(), Toast.LENGTH_LONG).show();

        fare = new information();
        listView = (ListView) findViewById(R.id.listview);
        //database = FirebaseDatabase.getInstance();
        //dref = database.getReference("fare");

        dref = FirebaseDatabase.getInstance().getReference("fare");
        list = new ArrayList<>();
        fare1 = new ArrayList<>();

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, list);



        dref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren())
                {

                    fare = ds.getValue(information.class);

                    list.add(fare.getPackage().toString() + "    " + fare.getPrice().toString()+ "    " +
                            fare.getValidity().toString());

                    fare1.add(new information(fare.getPackage(), fare.getPrice(), fare.getValidity()));

                }
                //listView.setAdapter(adapter);

                adapter1 = new fare_adapter(getApplicationContext(), fare1);
                listView.setAdapter(adapter1);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        //Toast.makeText(getApplicationContext(), list.get(i)+ "position : " + i, Toast.LENGTH_LONG).show();

                        ///String split
                        Pack = (list.get(i)).split("\\s+");

                        ///Alert
                      /*  AlertDialog.Builder builder = new AlertDialog.Builder(Fare_list.this);
                        builder.setTitle("Important");
                        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {


                                purchase();


                            }
                        });
                        builder.setMessage("Buy this package at " + Pack[1]);
                        AlertDialog alert = builder.create();
                        alert.show();*/

                        //CustomAlertDialog();


                        LayoutInflater inflater = LayoutInflater.from(Fare_list.this);
                        View v = inflater.inflate(R.layout.custom_dialog, null);

                        final AlertDialog alertDialog = new AlertDialog.Builder(Fare_list.this)
                                .setView(v)
                                .create();


                        Ok = v.findViewById(R.id.ok);
                        Cancel = v.findViewById(R.id.cancel);
                        text = v.findViewById(R.id.text_view);

                        text.setText("Buy " + Pack[0] + " package at " + Pack[1] + " tk ");

                        Ok.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                //Toast.makeText(getApplicationContext(), " OK ", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                                purchase();
                            }
                        });

                        Cancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                // Toast.makeText(getApplicationContext(), "Cancel", Toast.LENGTH_SHORT).show();
                                alertDialog.dismiss();
                            }
                        });


                        alertDialog.show();

                    }
                });
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }






    public void purchase(){

        Query query = FirebaseDatabase.getInstance().getReference("User_Package_info")
                .orderByChild("email")
                .equalTo(email.toString());


        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override

            public void onDataChange(DataSnapshot dataSnapshot) {


                // Toast.makeText(getApplicationContext(), "Checking pack", Toast.LENGTH_LONG).show();

                int count = 0;

                for (DataSnapshot ds: dataSnapshot.getChildren()){

                    count = 1;
                    info = ds.getValue(UPInfo.class);

                    DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

                    try {

                        Date ex_Date = df.parse(info.getExpire_date());


                        if(System.currentTimeMillis() <= ex_Date.getTime()){

                         /*   AlertDialog.Builder builder = new AlertDialog.Builder(Fare_list.this);
                            builder.setTitle("Important");
                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {


                                }
                            });
                            builder.setMessage("You already have an existing " + info.getPackage().toString() + " package " );
                            AlertDialog alert = builder.create();
                            alert.show();*/

                            CookieBar.build(Fare_list.this)
                                    .setTitle("Important")
                                    .setTitleColor(R.color.input_login)
                                    .setDuration(5000)
                                    .setIcon(R.drawable.ic_add_alert_black_24dp)
                                    .setMessage("You already have an existing " + info.getPackage().toString() + " package " )
                                    .setMessageColor(R.color.input_login)
                                    .setActionColor(R.color.input_login)
                                    .show();

                        }
                        else {

                            process();
                            ds.getRef().removeValue();

                        }

                    } catch (ParseException e) {

                    }


                }

                //Toast.makeText(getApplicationContext(), "count " + count , Toast.LENGTH_LONG).show();
                if(count == 0){
                    process();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });




    }


    public void process(){

        //Toast.makeText(getApplicationContext(), "don't have package..", Toast.LENGTH_LONG).show();

        dref = FirebaseDatabase.getInstance().getReference().child("Users");
        dref1 = FirebaseDatabase.getInstance().getReference().child("User_Package_info");


        dref.orderByChild("email")
                .equalTo(email.toString())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                        }

                        String acc_tk = dataSnapshot.child(key).child("Amount").getValue().toString();
                        int tk = Integer.parseInt(acc_tk);
                        int sub_tk = Integer.parseInt(Pack[1].toString());
                        if (tk >= sub_tk) {
                            String balance = Integer.toString(tk - sub_tk);
                            dref.child(key).child("Amount").setValue(balance);

                            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                            Calendar cal = Calendar.getInstance();

                            cal.add(Calendar.DATE, Integer.parseInt(Pack[3]));


                            String id = dref1.push().getKey();
                            dref1.child(id).child("Package").setValue(Pack[0]);
                            dref1.child(id).child("email").setValue(email.toString());
                            dref1.child(id).child("expire_date").setValue(dateFormat.format(cal.getTime()));


                       /*     AlertDialog.Builder builder = new AlertDialog.Builder(Fare_list.this);
                            builder.setTitle("Important");
                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {


                                }
                            });
                            builder.setMessage("Congrats...!!  Package bought successfully...");
                            AlertDialog alert = builder.create();
                            alert.show();*/

                            CookieBar.build(Fare_list.this)
                                    .setTitle("Important")
                                    .setTitleColor(R.color.input_login)
                                    .setDuration(5000)
                                    .setIcon(R.drawable.ic_done_all_black_24dp)
                                    .setMessage( "Congrats...!!  Package bought successfully...")
                                    .setMessageColor(R.color.input_login)
                                    .setActionColor(R.color.input_login)
                                    .show();

                        } else {

                           /* AlertDialog.Builder builder = new AlertDialog.Builder(Fare_list.this);
                            builder.setTitle("Important");
                            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {


                                }
                            });
                            builder.setMessage("Not enough Balance,, recharge and try again..");
                            AlertDialog alert = builder.create();
                            alert.show();*/



                            CookieBar.build(Fare_list.this)
                                    .setTitle("Important")
                                    .setTitleColor(R.color.input_login)
                                    .setDuration(5000)
                                    .setIcon(R.drawable.ic_add_alert_black_24dp)
                                    .setMessage( "Not enough Balance, Recharge and try again..")
                                    .setMessageColor(R.color.input_login)
                                    .setActionColor(R.color.input_login)
                                    .setAction("Ok", new OnActionClickListener() {
                                        @Override
                                        public void onClick() {

                                        }
                                    })
                                    .show();


                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

    }



    public void displayAlertMessage(String message,  DialogInterface.OnClickListener listener)
    {
        new AlertDialog.Builder(Fare_list.this)
                .setMessage(message)
                .setPositiveButton("Ok", listener)
                .setNegativeButton("Cancel", null)
                .create()
                .show();
    }

    public void setDataToView(FirebaseUser user) {
        email = user.getEmail();

    }






}
