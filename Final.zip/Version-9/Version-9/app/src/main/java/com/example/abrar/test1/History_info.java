package com.example.abrar.test1;

public class History_info {

    private String email;
    private String date;
    private String start;
    private String end;
    private String time;

    public History_info(){

    }
    public History_info(String email,String start,String end,String date,String time){
        this.email = email;
        this.date = date;

        this.start = start;
        this.end = end;
        this.time = time;

    }

    public
    String getTime() {
        return time;
    }

    public
    void setTime(String time) {
        this.time = time;
    }

    public
    String getEmail() {
        return email;
    }

    public
    void setEmail(String email) {
        this.email = email;
    }

    public
    String getDate() {
        return date;
    }

    public
    void setDate(String date) {
        this.date = date;
    }



    public
    String getStart() {
        return start;
    }

    public
    void setStart(String start) {
        this.start = start;
    }
    public
    String getEnd() {
        return end;
    }

    public
    void setEnd(String end) {
        this.end = end;
    }
}
