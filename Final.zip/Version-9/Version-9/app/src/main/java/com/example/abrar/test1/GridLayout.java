package com.example.abrar.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;

public
class GridLayout extends AppCompatActivity implements View.OnClickListener{

    private CardView Account_grid,Map_grid,Package_grid,Trip_grid,Qrd_grid,feedback_grid;

    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_grid_layout );

        Account_grid = (CardView)findViewById( R.id.Account_Grid);
        Map_grid = (CardView)findViewById( R.id.map_Grid);
        Package_grid = (CardView)findViewById( R.id.Package_Grid);
        Trip_grid = (CardView)findViewById( R.id.TripPlans_Grid);
        Qrd_grid = (CardView)findViewById( R.id.Qr_grid);
        feedback_grid = (CardView)findViewById( R.id.feedback_Grid);


        Account_grid.setOnClickListener( this );
        Map_grid.setOnClickListener( this );
        Package_grid.setOnClickListener( this );
        Trip_grid.setOnClickListener( this );
        Qrd_grid.setOnClickListener( this );
        feedback_grid.setOnClickListener( this );
    }

    @Override
    public
    void onClick(View v) {
        Intent intent;
      switch (v.getId()){
          case R.id.Account_Grid:
              {
              intent = new Intent( this,UserAcc.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              break;
          }
          case R.id.map_Grid:{
              intent = new Intent( this,BusStop.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              finish();
              break;
          }
          case R.id.Package_Grid:{
              intent = new Intent( this,Fare_list.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              break;
          }
          case R.id.TripPlans_Grid:{
              intent = new Intent( this,TrippPlanner.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              break;
          }
          case R.id.Qr_grid:{
              intent = new Intent( this,HistoryAct.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              break;
          }
          case R.id.feedback_Grid:{
              intent = new Intent( this,feedback2.class );
              intent.putExtra("Email", getIntent().getExtras().getString("Email"));
              startActivity( intent );
              break;
          }
      }

    }
}
