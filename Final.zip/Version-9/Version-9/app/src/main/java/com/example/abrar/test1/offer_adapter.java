package com.example.abrar.test1;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class offer_adapter extends BaseAdapter {

    private Context mContext;
    private List<information>offer_info;

    public offer_adapter(Context mContext, List<information>offer_info) {
        this.mContext = mContext;
        this.offer_info = offer_info;
    }

    @Override
    public int getCount() {
        return offer_info.size();
    }

    @Override
    public Object getItem(int i) {
        return offer_info.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(mContext, R.layout.offer_package, null);
        TextView tvName = (TextView)v.findViewById(R.id.Name);
        TextView tvPrice = (TextView) v.findViewById(R.id.description);

        tvName.setText("Package name: " + offer_info.get(i).getName());
        tvPrice.setText("Validity and Price: " + offer_info.get(i).getDescription());


        v.setTag(offer_info.get(i).getName());
        v.setTag(offer_info.get(i).getDescription());


        return v;
    }
}
