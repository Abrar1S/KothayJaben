package com.example.abrar.test1;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.abrar.test1.R;
import com.example.abrar.test1.information;

import java.util.List;

public class fare_adapter extends BaseAdapter {

    private Context mContext;
    private List<information>fare_info;

    public fare_adapter(Context mContext, List<information> fare_info) {
        this.mContext = mContext;
        this.fare_info = fare_info;
    }

    @Override
    public int getCount() {
        return fare_info.size();
    }

    @Override
    public Object getItem(int i) {
        return fare_info.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = View.inflate(mContext, R.layout.fare_package, null);
        TextView tvName = (TextView)v.findViewById(R.id.Package_name);
        TextView tvPrice = (TextView) v.findViewById(R.id.Price);
        TextView tvValidity = (TextView) v.findViewById(R.id.Validity);

        tvName.setText("Package name: " + fare_info.get(i).getPackage());
        tvPrice.setText("Price: " + fare_info.get(i).getPrice());
        tvValidity.setText("Validity: " + fare_info.get(i).getValidity());


        v.setTag(fare_info.get(i).getPackage());
        v.setTag(fare_info.get(i).getPrice());
        v.setTag(fare_info.get(i).getValidity());


        return v;
    }
}
