package com.example.abrar.test1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserAcc extends AppCompatActivity {

    private TextView Email;
    private TextView Package;
    private TextView Balance;
    private TextView Name;
    private TextView Phone;
    private Button UpImg;
    private Button Pass;
    public String email;
    public String key;

    private ImageView imageView;
    FirebaseDatabase database;
    DatabaseReference dref;
    UPInfo info;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_acc);

        Email= (TextView) findViewById(R.id.Email);
        imageView = (ImageView) findViewById(R.id.UserImage);
        Balance =  (TextView) findViewById(R.id.Balance);
        Package = (TextView) findViewById(R.id.Package);
        Name = (TextView) findViewById(R.id.Name);
        Phone = (TextView) findViewById(R.id.Phone);
        UpImg = (Button) findViewById(R.id.update_image);
        Pass = (Button) findViewById(R.id.Pass);



        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        setDataToView(user);

        info = new UPInfo();

        Query query = FirebaseDatabase.getInstance().getReference("User_Package_info")
                .orderByChild("email")
                .equalTo(email);

        Package.setText("Package: No active package");
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    info = ds.getValue(UPInfo.class);
                    DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
                    try {
                        Date ex_Date = df.parse(info.getExpire_date());
                        if(System.currentTimeMillis() <= ex_Date.getTime()){

                            Package.setText("Package: " + info.getPackage().toString() + "\n"
                                 + "         "   + "Validity: "  + info.getExpire_date());
                        }
                        else {
                            Package.setText("Package: No active package");
                        }

                    } catch (ParseException e) {
                        e.printStackTrace();
                    }


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });



        dref = FirebaseDatabase.getInstance().getReference().child("Users");

        dref.orderByChild("email")
                .equalTo(email)
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot child : dataSnapshot.getChildren()) {
                            key = child.getKey();
                        }
                    Balance.setText("Balance: " + dataSnapshot.child(key).child("Amount").getValue().toString() +" tk");
                    Phone.setText(dataSnapshot.child(key).child("phone").getValue().toString());
                    Name.setText(dataSnapshot.child(key).child("name").getValue().toString());
                       // Toast.makeText(getApplicationContext()," " + key , Toast.LENGTH_SHORT ).show();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


    }

    @Override
    protected void onStart() {
        super.onStart();

        Query query = FirebaseDatabase.getInstance().getReference("Users")
                .orderByChild("email")
                .equalTo(email);

        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


            for(DataSnapshot snapshot: dataSnapshot.getChildren()){
                ImageUploader imageUploader = snapshot.getValue(ImageUploader.class);

               // String message = (String)  dataSnapshot.getValue();
               // Name.setText(imageUploader.getName());
                Picasso.get()
                        .load(imageUploader.getUrl())
                        .fit()
                        .centerCrop()
                        .into(imageView);
            }
                //Email.setText("Email : "  + getIntent().getExtras().getString("Email"));


                UpImg.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(UserAcc.this, Profile.class);
                        //intent.putExtra("Email", getIntent().getExtras().getString("Email"));
                        startActivity(intent);
                    }
                });

                Pass.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        Intent intent = new Intent(UserAcc.this, MainActivity.class);
                        intent.putExtra("Email", email);
                        startActivity(intent);
                        finish();
                    }
                });


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }



    @SuppressLint("SetTextI18n")
    private void setDataToView(FirebaseUser user) {

        Email.setText(user.getEmail());
        email = user.getEmail();

    }
}
