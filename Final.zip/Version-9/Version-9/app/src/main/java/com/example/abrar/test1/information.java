package com.example.abrar.test1;


import java.lang.ref.SoftReference;

public class information {

    private String Mirpur;
    private String Stpg0;
    private String Stpg1;
    private String stpg2;
    private String Stpg3;
    private String stpg4;
    private String Stpg5;
    private String stpg6;
    private String Stpg7;
    private String stpg8;
    private String Stpg9;
    private String name;
    private String description;
    private String Package;
    private String price;
    private String validity;
    private String email;



    public information(String Package, String price, String validity){
        this.Package = Package;
        this.price = price;
        this.validity = validity;
    }

    public information(String name, String description){
        this.name = name;
        this.description = description;
    }
    public information() {
    }

    public
    String getMirpur() {
        return Mirpur;
    }
    public void setMirpur(String Mirpur){
        Mirpur = Mirpur;
    }
    public
    String getStpg0() {
        return Stpg0;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStpg1() {
        return Stpg1;
    }

    public void setStpg1(String stpg1) {

        Stpg1 = stpg1;
    }

    public String getStpg2() {
        return stpg2;
    }

    public void setStpg2(String stpg2) {
        this.stpg2 = stpg2;
    }

    public String getStpg3() {
        return Stpg3;
    }

    public void setStpg3(String stpg3) {
        Stpg3 = stpg3;
    }

    public String getStpg4() {
        return stpg4;
    }

    public void setStpg4(String stpg4) {
        this.stpg4 = stpg4;
    }

    public String getStpg5() {
        return Stpg5;
    }

    public void setStpg5(String stpg5) {
        Stpg5 = stpg5;
    }

    public String getStpg6() {
        return stpg6;
    }

    public void setStpg6(String stpg6) {
        this.stpg6 = stpg6;
    }

    public String getStpg7() {
        return Stpg7;
    }

    public void setStpg7(String stpg7) {
        Stpg7 = stpg7;
    }

    public String getStpg8() {
        return stpg8;
    }

    public void setStpg8(String stpg8) {
        this.stpg8 = stpg8;
    }

    public String getStpg9() {
        return Stpg9;
    }

    public void setStpg9(String stpg9) {
        Stpg9 = stpg9;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPackage() {
        return Package;
    }

    public void setPackage(String aPackage) {
        Package = aPackage;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getValidity() {
        return validity;
    }

    public void setValidity(String validity) {
        this.validity = validity;
    }


}
