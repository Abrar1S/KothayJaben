package com.example.abrar.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Feedback extends AppCompatActivity {

    private TextView F_Email;
    private EditText feedback;
    private Button button;

    DatabaseReference dref;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        dref = FirebaseDatabase.getInstance().getReference("feedback");

        F_Email = (TextView) findViewById(R.id.mail);
        feedback = (EditText) findViewById(R.id.feedback);
        button = (Button) findViewById(R.id.btnFdbk);

        F_Email.setText(getIntent().getExtras().getString("Email"));

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addFeedback();
                feedback.setText("");

            }
        });

    }
    private void  addFeedback()
    {
        String Fdbk = feedback.getText().toString();

        if(!TextUtils.isEmpty(Fdbk)){

            String F_id = dref.push().getKey();

           // Fdbk feedback = new Fdbk(F_Email.getText().toString(), Fdbk );


            dref.child(F_id).setValue(feedback);

            Toast.makeText(this, "Feedback given, Thank you!!", Toast.LENGTH_LONG).show();

        }
        else {
            Toast.makeText(this,"Please give some valuable feedback", Toast.LENGTH_LONG).show();
        }
    }


}
