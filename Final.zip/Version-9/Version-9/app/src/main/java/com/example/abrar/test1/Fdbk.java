package com.example.abrar.test1;

public class Fdbk {

    private String description;
    private String Email;
    private String F_id;
    private String date;
    private String time;

    public Fdbk(String email, String description,String dates, String time) {
        this.description = description;
        this.Email = email;
        this.date = dates;
        this.time = time;

    }
    public Fdbk(){

    }

    public
    String getDate() {
        return date;
    }

    public
    void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getF_id() {
        return F_id;
    }

    public void setF_id(String f_id) {
        F_id = f_id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
