package com.example.abrar.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListView;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class route_list extends AppCompatActivity {

    ExpandableListView expandableListview;
    ExpandableListAdapter route;
    //  ExpandableListAdapter rt;
    information rt;
    // ListView listView;
    FirebaseDatabase database;
    DatabaseReference dref;
    List <String> list;
    ArrayAdapter <String> adapter;
    HashMap <String, List <String>> listHashMap;


    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_route_list );

        //rt = (ListAdapter) new information();
        rt = new information();
        //listView = (ListView) findViewById(R.id.listview);
        expandableListview = (ExpandableListView) findViewById( R.id.ExpandableList );
        database = FirebaseDatabase.getInstance();
        dref = database.getReference( "Route" );
        initData();
        route = new ExpandableListAdapter( this, list, listHashMap );
        expandableListview.setAdapter( route );

        //list = new ArrayList <>();
        //  listHashMap = new HashMap <>();
        //adapter = new ArrayAdapter <String>( this, android.R.layout.simple_dropdown_item_1line, list );



    }

    private void initData(){
        list = new ArrayList <>();
        listHashMap = new HashMap <>();

        list.add( "Start: Gabtoli" );

        List <String> rout1 = new ArrayList <>();
        rout1.add( "Mirpur-1" );
        rout1.add( "Mirpur-10" );
        rout1.add( "Kalshi" );
        rout1.add( "Jamuna FUture Park" );
        rout1.add( "Natun Bazar" );
        rout1.add( "Badda" );

        list.add( "Start: Shiya Masjid" );

        List <String> rout2 = new ArrayList <>();
        rout2.add( "Shyamoli" );
        rout2.add( "Agargaon" );
        rout2.add( "MIrpur-10" );
        rout2.add( "Kalshi" );
        rout2.add( "Bisshoroad" );
        rout2.add( "Airport" );
        rout2.add( "Uttora" );
        rout2.add( "Abdullahpur" );

        list.add( "Start: Mirpur Sony Cinema Hall" );

        List <String> rout3 = new ArrayList <>();
        rout3.add( "Mirpur-10" );
        rout3.add( "Kazipara" );
        rout3.add( "Shewrapara" );
        rout3.add( "Mohakhali" );
        rout3.add( "Gulshan1" );
        rout3.add( "Badda" );
        rout3.add( "Rampura" );
        rout3.add( "Banasree" );

        list.add( "Start: Mirpur-10" );

        List <String> rout4 = new ArrayList <>();
        rout4.add( "Cantonment" );
        rout4.add( "Banani" );
        rout4.add( "Notun bazar" );

        list.add( "Start: Mirpur-12" );

        List <String> rout5 = new ArrayList <>();
        rout5.add( "MIrpur-10" );
        rout5.add( "Agargoan" );
        rout5.add( "Farmgate" );
        rout5.add( "Shahbag" );
        rout5.add( "Motijhil" );

        list.add( "Start: Azimpur" );

        List <String> rout6 = new ArrayList <>();
        rout6.add( "Kolabagan" );
        rout6.add( "Karwan bazar" );
        rout6.add( "Nabisco" );
        rout6.add( "Mohakhali" );
        rout6.add( "Gulshan 1" );
        rout6.add( "Badda Link Road" );
        rout6.add( "Kuril Bisso Road" );


        listHashMap.put( list.get(0),rout1);
        listHashMap.put( list.get(1),rout2);
        listHashMap.put( list.get(2),rout3);
        listHashMap.put( list.get(3),rout4);
        listHashMap.put( list.get(4),rout5);
        listHashMap.put( list.get(5),rout6);



    }


      /*  dref.addValueEventListener( new ValueEventListener() {
            @Override
            public
            void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    rt = ds.getValue( information.class );

                    // list.add(route.getStpg0().toString());
                    list.add( rt.getMirpur().toString() );
                    List <String> rout1 = new ArrayList <>();
                    rout1.add( rt.getStpg1().toString() );
                   /* list.add( rt.getStpg3().toString() );
                    list.add( rt.getStpg4().toString() );
                    list.add( rt.getStpg5().toString() );
                    list.add( rt.getStpg6().toString() );
                    list.add( rt.getStpg7().toString() );
                    list.add( rt.getStpg8().toString() );
                    list.add( rt.getStpg9().toString() );


                }
                expandableListview.setAdapter( adapter );
            }

            @Override
            public
            void onCancelled(DatabaseError databaseError) {

            }
        } );*/

}

