package com.example.abrar.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class Splash extends AppCompatActivity {
    private ProgressBar mProgressbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        ImageView i = findViewById(R.id.ImageVIew);
        mProgressbar = findViewById( R.id.progressBar );
        Animation a = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.mytransition);
        i.startAnimation(a);
        final Intent in = new Intent(this,Login.class);
        Thread timer = new Thread() {
            public void run() {

                    try {
                        for (int p = 0; p < 100; p += 25) {
                            sleep( 1000 );
                            mProgressbar.setProgress( p );
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        startActivity( in );
                        finish();
                    }
                }
        };
        timer.start();
    }
}
