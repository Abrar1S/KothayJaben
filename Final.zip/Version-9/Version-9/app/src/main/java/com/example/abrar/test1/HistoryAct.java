package com.example.abrar.test1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.net.FileNameMap;
import java.util.ArrayList;

public
class HistoryAct extends AppCompatActivity {

    ListView listView;
    private HistoryAdapter adapter;
    FirebaseDatabase database;
    DatabaseReference dref;
    ArrayList<History_info> list;
    // ArrayAdapter<String> adapter;
    History_info history_info1;

    TextView tvdate,tvend,tvstart;


    @Override
    protected
    void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_history );

        final String email = getIntent().getStringExtra("Email");


        history_info1 = new History_info();

        listView = (ListView) findViewById(R.id.History);


        Query query = FirebaseDatabase.getInstance().getReference("History")
                .orderByChild("email")
                .equalTo(email);

        list = new ArrayList<>();
        adapter = new HistoryAdapter(getApplicationContext(), list);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {


                for(DataSnapshot ds: dataSnapshot.getChildren()){
                    history_info1 = ds.getValue(History_info.class);

                   /* final String email = inputEmail.getText().toString().trim();
                    final String password = inputPassword.getText().toString().trim();
                    final String name = inputName.getText().toString().trim();
                    final String phone = inputPhn.getText().toString().trim();*/

                    //list.add(history_info1.getEmail());
                    //list.add( history_info1.getEmail());

                    // list.add(new History_info( History_info.getEmail(),History_info.getDate(),History_info.getStart(),History_info.getEnd()));
                    //list.add(new History_info( "a","b","c","d"));
                    list.add(

                            new History_info("Email: "+history_info1.getEmail(),"From: "+history_info1.getStart(),"To: "+history_info1.getEnd(),"Date: "+history_info1.getDate(),"Time: "+history_info1.getTime()

                            )
                            // new History_info( history_info1.getDate(),history_info1.getEmail(),history_info1.getStart(),history_info1.getEnd()) );
                            // new History_info( history_info1.getStart(),history_info1.getDate(),history_info1.getEmail(),history_info1.getEnd()) +
                            // new History_info( history_info1.getEnd(),history_info1.getDate(),history_info1.getStart(),history_info1.getEmail() )

                    );

                    // list.add(new History_info("Email address: " + history_info1.getEmail(),"Start point: "  + history_info1.getDate(),"End point: " + history_info1.getEnd().toString()+"Date point: " + history_info1.getDate().toString()));

                }

                listView.setAdapter(adapter);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
}
